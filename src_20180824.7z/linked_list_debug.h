
#ifndef LINKED_LIST_DEBUG_H_
#define LINKED_LIST_DEBUG_H_

#undef LINKED_LIST_DEBUG

#ifndef LINKED_LIST_DEBUG
#else
//include actual header for printf
#include <stdio.h>
#endif

#endif
